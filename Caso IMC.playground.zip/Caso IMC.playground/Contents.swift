import UIKit
import ObjectiveC

/*
 
 
 Teniendo ciertos datos de 6 personas, se crea una lista de personas que contenga datos como nombre, apellido paterno, apellido materno, fecha de nacimiento, nro de documento, sexo, correo, la cantidad de hermanos y usuario de cada persona.

 A partir de esta lista:

 1.0- Obtener la persona con mayor y menor edad
 2.0- Obtener dos listas más, una para hombres y otra mara mujeres e imprimir la cantidad de personas que hay en cada lista
 3.0- Obtener una lista de todas las personas que tienen más de dos hermanos
 4.0- Imprimir cada persona con este formato “Luis Inga M.” Solo primer nombre, ape pate completo y solo la inicial del ape mate más un punto. *Y EN CAPITALIZE* (primera letra de cada palabra en mayúscula y todo lo demás en minúscula)
 5.0- Crear usuarios a todas las personas y guardar en la lista.

 NOTA

 No te vendrá el usuario de por sí, por lo que ese campo será nulo al inicio. Tendrás que obtenerlo a partir del correo. Si mi correo es luis.ingam@gmail.com, entonces mi usuario es  luis.ingam

 Lo obtengo con todo lo que hay antes de la arroba @
 
 CARLOS JOSÉ ROBLES GOMES, fecha de nacimiento: 06/08/1995, numero de documento 78451245, tiene 2 hermanos, carlos.roblesg@hotmail.com
 MIGUEL ANGEL QUISPE OTERO, fecha de nacimiento: 28/12/1995, numero de documento 79451654, no tiene hermanos, miguel.anguel@gmail.com
 KARLA ALEXANDRA FLORES ROSAS, fecha de nacimiento: 15/02/1997, numero de documento 77485812, tiene 1 hermanos, Karla.alexandra@hotmail.com
 NICOLAS QUISPE ZEBALLOS, fecha de nacimiento: 08/10/1990, numero de documento 71748552, tiene 1 hermanos, nicolas123@gmail.com
 PEDRO ANDRE PICASSO BETANCUR, fecha de nacimiento: 17/05/1994, numero de documento 74823157, tiene 2 hermanos, pedroandrepicasso@gmail.com
 FABIOLA MARIA PALACIO VEGA, fecha de nacimiento: 02/02/1992, numero de documento 76758254, no tiene hermanos, fabi@hotmail.com]
 */
let persona1 = (Nombre: "CARLOS JOSÉ", ApellidoPaterno:"ROBLES",  ApellidoMaterno: "GOMES", birthday: "1995-08-06", DNI:78451245, sexo:"M", correo: "carlos.roblesg@hotmail.com",cantidadDeHermanos:2, UserID:"carlos.robles")

let persona2 = (Nombre: "MIGUEL ANGEL", ApellidoPaterno:"QUISPE",  ApellidoMaterno: "OTERO", birthday: "1995-12-28", DNI:79451654, sexo:"M", correo: "miguel.anguel@gmail.com",cantidadDeHermanos:0, UserID:"miguel.angel")

let persona3 = (Nombre: "KARLA ALEXANDRA", ApellidoPaterno:"FLORES",  ApellidoMaterno: "R0SAS", birthday:"1997-02-15", DNI:77485812, sexo:"F", correo: "karla.alexandra@gmail.com",cantidadDeHermanos:1, UserID:"karla.alexandra")

let persona4 = (Nombre: "NICOLAS", ApellidoPaterno:"QUISPE",  ApellidoMaterno: "CEVALLOS", birthday: "1990-10-08", DNI:71748552, sexo:"M", correo: "nicolas123@gmail.com",cantidadDeHermanos:1, UserID:"nicolas123")

let persona5 = (Nombre: "PEDRO ANDRE", ApellidoPaterno:"PICASSO",  ApellidoMaterno: "BETANCUR", birthday:"1994-05-17", DNI:71748552, sexo:"M", correo: "pedroandrepicasso@gmail.com",cantidadDeHermanos:2, UserID:"pedroandrepicasso")

let persona6 = (Nombre: "FABIOLA MARIA", ApellidoPaterno:"PALACIO",  ApellidoMaterno: "VEGA", birthday:"1992-02-02", DNI:76758254, sexo:"F", correo: "fabi@hotmail.com",cantidadDeHermanos:0, UserID:"fabi")

// SOLUCION 1.0
// Obtener la Edad de las personas por medio de su fecha de nacimiento


var dateFormatter : DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.locale = Locale(identifier: "en_US_POSIX")
        return formatter
    }()


let birthday1 = dateFormatter.date(from: persona1.3)
let timeInterval1 = birthday1?.timeIntervalSinceNow
let age1 = abs(Int(timeInterval1! / 31556926.0))

let birthday2 = dateFormatter.date(from: persona2.3)
let timeInterval2 = birthday2?.timeIntervalSinceNow
let age2 = abs(Int(timeInterval2! / 31556926.0))

let birthday3 = dateFormatter.date(from: persona3.3)
let timeInterval3 = birthday3?.timeIntervalSinceNow
let age3 = abs(Int(timeInterval3! / 31556926.0))

let birthday4 = dateFormatter.date(from: persona4.3)
let timeInterval4 = birthday4?.timeIntervalSinceNow
let age4 = abs(Int(timeInterval4! / 31556926.0))

let birthday5 = dateFormatter.date(from: persona5.3)
let timeInterval5 = birthday5?.timeIntervalSinceNow
let age5 = abs(Int(timeInterval5! / 31556926.0))

let birthday6 = dateFormatter.date(from: persona4.3)
let timeInterval6 = birthday6?.timeIntervalSinceNow
let age6 = abs(Int(timeInterval6! / 31556926.0))

let listage = [persona1.0 :age1, persona2.0:age2, persona3.0:age3, persona4.0:age4, persona5.0:age5, persona6.0:age6]
print(listage)

// Obtiene la persona de mayor y la persona de menor Edad

let mayorEdad = listage.max { $0.value < $1.value }
let menorEdad = listage.min { $0.value < $1.value }

// RESPUESTA FINAL 1.0
print("La persona de mayor edad y su edad : \(mayorEdad!)")
print("La persona de menor edad y su edad: \(menorEdad!)")


// SOLUCION 2.0
//Obtener dos listas más, una para hombres y otra para mujeres e imprimir la cantidad de personas que hay en cada lista

// Creamos una lista vacia de mujeres y hombres.

var mujeres = [String:String]()
var hombres = [String:String]()

if persona1.5 == "F" {
    // agregamos El Key que en este caso es el nombre de la mujer (persona1.Nombre)y el value que en este caso es "F" (persona1.sexo) de Femenino
    mujeres[persona1.Nombre]=persona1.sexo
}else{
    hombres[persona1.Nombre]=persona1.sexo
}
if persona2.sexo == "F" {
    mujeres[persona2.Nombre]=persona2.sexo
}else{
    hombres[persona2.Nombre]=persona2.sexo
}
if persona3.sexo == "F" {
    print(mujeres.count)
    mujeres[persona3.Nombre]=persona3.sexo
}else{
    hombres[persona3.Nombre]=persona1.sexo
}
if persona4.sexo == "F" {
    print(mujeres.count)
    mujeres[persona4.Nombre]=persona4.sexo
}else{
    hombres[persona4.Nombre]=persona4.sexo
}
if persona5.sexo == "F" {
    mujeres[persona1.Nombre]=persona5.sexo
}else{
    hombres[persona5.Nombre]=persona5.sexo
}
if persona6.sexo == "F" {
    mujeres[persona6.Nombre]=persona6.sexo
    
}else{
    hombres[persona6.Nombre]=persona6.sexo
    
}
//- Obtener dos listas más, una para hombres y otra mara mujeres e imprimir la cantidad de personas que hay en cada lista

print(mujeres)
print(hombres)
// RESPUESTA FINAL 2.0
print("Cantidad de mujeres:  \(mujeres.count)")
print("Cantidad de hombres:  \(hombres.count)")

//Obtener una lista de todas las personas que tienen más de dos hermanos

// SOLUCION 3.0
var personasconmasdedoshermanos = [String:Int]()

if persona1.cantidadDeHermanos >= 2 {
    // Agregamos El Key que en este caso es el nombre de la persona persona1.0 y el value que en este caso es el numero de hermanos que tiene la persona item persona#.7
    personasconmasdedoshermanos[persona1.Nombre]=persona1.cantidadDeHermanos
}

if persona2.cantidadDeHermanos >= 2 {
    // Agregamos El Key que en este caso es el nombre de la persona persona1.0 y el value que en este caso es el numero de hermanos que tiene la persona item persona#.7
    personasconmasdedoshermanos[persona2.Nombre]=persona2.cantidadDeHermanos
}

if persona3.cantidadDeHermanos >= 2 {
    // Agregamos El Key que en este caso es el nombre de la persona persona1.0 y el value que en este caso es el numero de hermanos que tiene la persona item persona#.7
    personasconmasdedoshermanos[persona3.Nombre]=persona3.cantidadDeHermanos
}
if persona4.cantidadDeHermanos >= 2 {
    // Agregamos El Key que en este caso es el nombre de la persona persona1.0 y el value que en este caso es el numero de hermanos que tiene la persona item persona#.7
    personasconmasdedoshermanos[persona4.Nombre]=persona4.cantidadDeHermanos
}
if persona5.cantidadDeHermanos >= 2 {
    // Agregamos El Key que en este caso es el nombre de la persona persona1.0 y el value que en este caso es el numero de hermanos que tiene la persona item persona#.7
    personasconmasdedoshermanos[persona5.Nombre]=persona5.cantidadDeHermanos
}

if persona5.cantidadDeHermanos >= 2 {
    // Agregamos El Key que en este caso es el nombre de la persona persona1.0 y el value que en este caso es el numero de hermanos que tiene la persona item persona#.7
    personasconmasdedoshermanos[persona5.Nombre]=persona5.cantidadDeHermanos
}
if persona6.cantidadDeHermanos >= 2 {
    // Agregamos El Key que en este caso es el nombre de la persona persona1.0 y el value que en este caso es el numero de hermanos que tiene la persona item persona#.7
    personasconmasdedoshermanos[persona6.Nombre]=persona6.cantidadDeHermanos
}

// RESPUESTA FINAL 3.0
print("Personas con 2 o mas Hermanos: \(personasconmasdedoshermanos)")


// SOLUCION 4.0
//Imprimir cada persona con este formato “Luis Inga M.” Solo primer nombre, ape pate completo y solo la inicial del ape mate más un punto. *Y EN CAPITALIZE* (primera letra de cada palabra en mayúscula y todo lo demás en minúscula)

// Declaramos una nueva variable para luego ponerlas en minusculas:el nombre , Apellido Paterno y el apellido materno
 // Declaramos los nombres y apellidos del primero en la lista
var person1Nombre = persona1.Nombre // Variable Nombre
var person1AP = persona1.ApellidoPaterno // Variable de Apellido Paterno
var person1AM = persona1.ApellidoMaterno // Variable de Apellido Materno

// Declaramos los nombres y apellidos del segundo en la lista
var person2Nombre = persona2.Nombre // Variable Nombre
var person2AP = persona2.ApellidoPaterno // Variable de Apellido Paterno
var person2AM = persona2.ApellidoMaterno // Variable de Apellido Materno

// Declaramos los nombres y apellidos del tercero en la lista
var person3Nombre = persona3.Nombre // Variable Nombre
var person3AP = persona3.ApellidoPaterno // Variable de Apellido Paterno
var person3AM = persona3.ApellidoMaterno // Variable de Apellido Materno

// Declaramos los nombres y apellidos del cuarto en la lista
var person4Nombre = persona4.Nombre // Variable Nombre
var person4AP = persona4.ApellidoPaterno // Variable de Apellido Paterno
var person4AM = persona4.ApellidoMaterno // Variable de Apellido Materno

// Declaramos los nombres y apellidos del quinto en la lista
var person5Nombre = persona5.Nombre // Variable Nombre
var person5AP = persona5.ApellidoPaterno // Variable de Apellido Paterno
var person5AM = persona5.ApellidoMaterno // Variable de Apellido Materno

// Declaramos los nombres y apellidos del sexto en la lista
var person6Nombre = persona6.Nombre // Variable Nombre
var person6AP = persona6.ApellidoPaterno // Variable de Apellido Paterno
var person6AM = persona6.ApellidoMaterno // Variable de Apellido Materno

// Funcion para Poner en mayuscula la primera letra de un String
extension StringProtocol {
    var firstUppercased: String { prefix(1).uppercased() + dropFirst() }
    var firstCapitalized: String { prefix(1).capitalized + dropFirst() }
}
// Utilizamos las variables person1Nombre , person1AP  y person1AM  (que son el nombre , apellido paterno y apellido Materno para poder poneras en minusculas todo el string
// y las ponemos en minuscula con .lowercased() y luego ponemos en Mayuscula la primera letra
// de cada palabra

// Se pone todo el nombre en minuscula y la primera letra en mayuscula de todos los nombres:

var nome1 = person1Nombre.lowercased().firstUppercased
var nome2 = person2Nombre.lowercased().firstUppercased
var nome3 = person3Nombre.lowercased().firstUppercased
var nome4 = person4Nombre.lowercased().firstUppercased
var nome5 = person5Nombre.lowercased().firstUppercased
var nome6 = person6Nombre.lowercased().firstUppercased

// removemos el segundo nombre de Carlos josé (josé)

// position of the character to remove
var i1 = nome1.index(nome1.startIndex, offsetBy: 6)
// Eliminar el Caracter numero 6 en este caso es " "
nome1.remove(at: i1)
var j1 = nome1.index(nome1.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "j"
nome1.remove(at: j1)
var k1 = nome1.index(nome1.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "o"
nome1.remove(at: k1)
var l1 = nome1.index(nome1.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "s"
nome1.remove(at: l1)
var m1 = nome1.index(nome1.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "é"
nome1.remove(at: m1)
// nos queda solo el nombre Carlos
print(nome1)

// removemos el segundo nombre de Miguel angel (angel) es decir nos queda solo Miguel

// position of the character to remove
var i2 = nome2.index(nome2.startIndex, offsetBy: 6)
// Eliminar el Caracter numero 6 en este caso es " "
nome2.remove(at: i2)
var j2 = nome2.index(nome2.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "a"
nome2.remove(at: j2)
var k2 = nome2.index(nome2.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "n"
nome2.remove(at: k2)
var l2 = nome2.index(nome2.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "g"
nome2.remove(at: l2)
var m2 = nome2.index(nome2.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "e"
nome2.remove(at: m2)
// nos queda solo el nombre Miguel
var N2 = nome2.index(nome2.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "l"
nome2.remove(at: N2)
print(nome2)

// removemos el segundo nombre de Karla alexandra (alexandras) es decir nos queda solo Karla

var i3 = nome3.index(nome3.startIndex, offsetBy: 5)
// Eliminar el Caracter numero 6 en este caso es " "
nome3.remove(at: i3)
var j3 = nome3.index(nome3.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "a"
nome3.remove(at: j3)
var k3 = nome3.index(nome3.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "l"
nome3.remove(at: k3)
var l3 = nome3.index(nome2.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "e"
nome3.remove(at: l3)
var m3 = nome3.index(nome2.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "x"
nome3.remove(at: m3)
// nos queda solo el nombre Miguel
var N3 = nome3.index(nome2.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "a"
nome3.remove(at: N3)
var o3 = nome3.index(nome2.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "n"
nome3.remove(at: o3)
var p3 = nome3.index(nome2.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "d"
nome3.remove(at: p3)
var q3 = nome3.index(nome2.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "r"
nome3.remove(at: q3)
var r3 = nome3.index(nome2.startIndex, offsetBy: 5)
//Eliminar el Caracter numero 6 en este caso es "a"
nome3.remove(at: r3)
nome3
// removemos el segundo nombre de Pedro andre (andre) es decir nos queda solo Pedro

var i5 = nome5.index(nome5.startIndex, offsetBy: 6)
// Eliminar el Caracter numero 6 en este caso es " "
nome5.remove(at: i5)
var j5 = nome5.index(nome5.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "a"
nome5.remove(at: j5)
var k5 = nome5.index(nome5.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "l"
nome5.remove(at: k5)
var l5 = nome5.index(nome5.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "e"
nome5.remove(at: l5)
var m5 = nome5.index(nome5.startIndex, offsetBy: 6)
//Eliminar el Caracter numero 6 en este caso es "x"
nome5.remove(at: m5)

nome5

// removemos el segundo nombre de Fabiola maria (maria) es decir nos queda solo Fabiola

var i6 = nome6.index(nome6.startIndex, offsetBy: 7)
// Eliminar el Caracter numero 6 en este caso es " "
nome6.remove(at: i6)
var j6 = nome6.index(nome6.startIndex, offsetBy: 7)
//Eliminar el Caracter numero 6 en este caso es "m"
nome6.remove(at: j6)
var k6 = nome6.index(nome6.startIndex, offsetBy: 7)
//Eliminar el Caracter numero 6 en este caso es "a"
nome6.remove(at: k6)
var m6 = nome6.index(nome6.startIndex, offsetBy: 7)
//Eliminar el Caracter numero 6 en este caso es "r"
nome6.remove(at: m6)
//nos queda solo el nombre Miguel
var N6 = nome6.index(nome6.startIndex, offsetBy: 7)
//Eliminar el Caracter numero 6 en este caso es "i"
nome6.remove(at: N6)
var o6 = nome6.index(nome6.startIndex, offsetBy: 7)
//Eliminar el Caracter numero 6 en este caso es "a"
nome6.remove(at: o6)

// ELiminacion del segundo de nome1  que es el nombre del primero de la lista ingresada

// Eliminacion del Todas las letras minusculas del Apellido Materno y colocar punto al final
var apellido1 = person1AM.lowercased().firstUppercased
var ip1 = apellido1.index(apellido1.startIndex, offsetBy: 1)
// Eliminar el Caracter numero 6 en este caso es " "
apellido1.remove(at: ip1)
var jp1 = apellido1.index(apellido1.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "j"
apellido1.remove(at: jp1)
var kp1 = apellido1.index(apellido1.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "k"
apellido1.remove(at: kp1)
var lp1 = apellido1.index(apellido1.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido1.remove(at: lp1)

//////////////////////////////////////////////////////////////////
var apellido2 = person2AM.lowercased().firstUppercased
var ip2 = apellido2.index(apellido2.startIndex, offsetBy: 1)
// Eliminar el Caracter numero 6 en este caso es " "
apellido2.remove(at: ip2)
var jp2 = apellido2.index(apellido2.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "j"
apellido2.remove(at: jp2)
var kp2 = apellido2.index(apellido2.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "k"
apellido2.remove(at: kp2)
var lp2 = apellido2.index(apellido2.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido2.remove(at: lp2)
apellido2

//////////////////////////////

var apellido3 = person3AM.lowercased().firstUppercased
var ip3 = apellido3.index(apellido3.startIndex, offsetBy: 1)
// Eliminar el Caracter numero 6 en este caso es " "
apellido3.remove(at: ip3)
var jp3 = apellido3.index(apellido3.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "j"
apellido3.remove(at: jp3)
var kp3 = apellido1.index(apellido3.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "k"
apellido3.remove(at: kp3)
var lp3 = apellido3.index(apellido3.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido3.remove(at: lp3)
apellido3



var apellido4 = person4AM.lowercased().firstUppercased
var ip4 = apellido4.index(apellido4.startIndex, offsetBy: 1)
// Eliminar el Caracter numero 6 en este caso es " "
apellido4.remove(at: ip4)
var jp4 = apellido4.index(apellido4.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "j"
apellido4.remove(at: jp4)
var kp4 = apellido4.index(apellido4.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "k"
apellido4.remove(at: kp4)
var lp4 = apellido4.index(apellido4.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido4.remove(at: lp4)
var op4 = apellido4.index(apellido4.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido4.remove(at: op4)
var qp4 = apellido4.index(apellido4.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido4.remove(at: qp4)
var rp4 = apellido4.index(apellido4.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido4.remove(at: rp4)
apellido4

var apellido5 = person5AM.lowercased().firstUppercased
var ip5 = apellido5.index(apellido5.startIndex, offsetBy: 1)
// Eliminar el Caracter numero 6 en este caso es " "
apellido5.remove(at: ip5)
var jp5 = apellido5.index(apellido5.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "j"
apellido5.remove(at: jp5)
var kp5 = apellido4.index(apellido5.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "k"
apellido5.remove(at: kp5)
var lp5 = apellido5.index(apellido5.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido5.remove(at: lp5)
var op5 = apellido5.index(apellido5.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido5.remove(at: op5)
var qp5 = apellido5.index(apellido5.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido5.remove(at: qp5)
var rp5 = apellido5.index(apellido5.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "l"
apellido5.remove(at: rp5)

//////////////////////////////////////
var apellido6 = person6AM.lowercased().firstUppercased
var ip6 = apellido6.index(apellido6.startIndex, offsetBy: 1)
// Eliminar el Caracter numero 6 en este caso es " "
apellido6.remove(at: ip6)
var jp6 = apellido6.index(apellido6.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "j"
apellido6.remove(at: jp6)
var kp6 = apellido6.index(apellido6.startIndex, offsetBy: 1)
//Eliminar el Caracter numero 6 en este caso es "k"
apellido6.remove(at: kp6)
apellido6

// insertamos el caracter "." despues de la Letra mayuscula del apellido Materno
apellido1.insert(".", at: apellido1.endIndex)

// insertamos el caracter "." despues de la Letra mayuscula del apellido Materno
apellido2.insert(".", at: apellido2.endIndex)

// insertamos el caracter "." despues de la Letra mayuscula del apellido Materno
apellido3.insert(".", at: apellido3.endIndex)

// insertamos el caracter "." despues de la Letra mayuscula del apellido Materno
apellido4.insert(".", at: apellido4.endIndex)

// insertamos el caracter "." despues de la Letra mayuscula del apellido Materno
apellido5.insert(".", at: apellido5.endIndex)

// insertamos el caracter "." despues de la Letra mayuscula del apellido Materno
apellido6.insert(".", at: apellido6.endIndex)


// RESPUESTA FINAL 4.0
// Iprimimos el Primer Nombre de la Persona la primera letra en Masyucula el apellido
// Paterno en Mayuscula y el apellido Matenro la primera letra en mayuscula seguido de un punto.
print(nome1 + " " + person1AP.lowercased().firstUppercased + " " + apellido1)
print(nome2 + " " + person2AP.lowercased().firstUppercased + " " + apellido2)
print(nome3 + " " + person3AP.lowercased().firstUppercased + " " + apellido3)
print(nome4 + " " + person4AP.lowercased().firstUppercased + " " + apellido4)
print(nome5 + " " + person5AP.lowercased().firstUppercased + " " + apellido5)
print(nome5 + " " + person5AP.lowercased().firstUppercased + " " + apellido6)
